function TableHeadercart() {
    return ( 
        <div style={{width:"100%" ,marginTop:"8px"}}>
      <table className="table">
        <div style={{backgroundColor:"orangered"}}>
          <tr>
            <th className="col-2" scope="col" style={{width:"5%"}}>#</th>
            <th className="col-4" scope="col" style={{width:"15%"}}>Item</th>
            <th className="col-2" scope="col"style={{width:"15%"}}>Item Name</th>
            <th className="col-2" scope="col"style={{width:"15%"}}>Quantity</th>
            <th className="col-2" scope="col"style={{width:"10%"}}>Price</th>
            <th className="col-2" scope="col"style={{width:"10%"}}>Remove</th>
            
          </tr>
        </div>
        </table>
        </div>
     );
}
export default TableHeadercart;