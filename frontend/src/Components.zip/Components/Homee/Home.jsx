import React, { Component } from "react";
import Header from "./Header";
import "../Styles/Home.css"
import Mcarousel from "./Carousel/Mcarousel";
import Pcarousel from "./Carousel/Pcarousel";
import Storeroom from "./Storeroom"


const Home = () => {
  return (
    <div className="chome">
      
      <div className="row ">
        <div className="col cheader">
          <Header />
        </div>
      </div>
      <div className="row ">
        <div className="col ccarousel">
          <Pcarousel />
        </div>
        <div className="col ccarousel">
          <Mcarousel />
        </div>
      </div>
      <div className="row">
        <div className="col cstoreroom">
          <Storeroom />
        </div>
        
      </div>
      
      </div>
  );
};

export default Home;
